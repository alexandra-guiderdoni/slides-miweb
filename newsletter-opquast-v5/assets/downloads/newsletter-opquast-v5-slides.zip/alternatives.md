# Alternatives textuelles - Newsletter et qualité numérique selon Opquast V5

Formation MiWeb - Support thématique

<!-- PDG-LARGE-FILE-JUSTIFICATION: export complet des 18 transcriptions et discours dans leur ordre, également distribué dans le ZIP. -->

## Slide 1 - Une newsletter, un service numérique complet

### Lecture du visuel

Une enveloppe relie sept stations de l’expérience de l’abonné : s’informer, choisir, confirmer, recevoir, consulter, se désinscrire puis retrouver les éditions.

### Le parcours de l’abonné

1. Savoir
2. Choisir
3. Confirmer
4. Recevoir
5. Consulter
6. Se désinscrire
7. Retrouver

### Idée directrice

Une newsletter, un service numérique complet.

### Message à retenir

La newsletter est un service complet, du choix initial à la consultation des archives.

### Discours oral

Partons d’une expérience familière : recevoir un message dont on ne se rappelle pas l’inscription, ou chercher comment arrêter les envois. La qualité ne se joue donc pas uniquement dans le courriel reçu.

Nous allons suivre l’expérience de l’abonné dans l’ordre : ce qu’il sait avant de s’inscrire, les choix qu’il fait et les possibilités qui restent ouvertes ensuite.

**Le parcours utilisateur : de l’inscription à la fin de service**

La qualité numérique est une continuité. Le cycle de vie d’un abonné doit être sécurisé à chaque étape du parcours utilisateur pour maintenir une relation de confiance durable.

1. **Collecte (abonnement)** - l’exigence est celle de la transparence totale. Le consentement doit résulter d’une action volontaire, excluant tout artifice technique.
2. **Confirmation** - cette étape de réassurance doit valider l’action et informer immédiatement sur la fréquence et la nature des envois.
3. **Réception et consultation** - l’utilisateur doit identifier l’expéditeur sans ouvrir le message. Le contenu doit respecter l’économie de données pour limiter l’impact environnemental invisible.
4. **Rupture de service (désabonnement)** - la simplicité de sortie est le garant de la qualité de service. Elle doit être immédiate, sans obstacle cognitif ou technique.

## Slide 2 - 9 règles au cœur de notre parcours

### Lecture du visuel

Les neuf règles sont réparties en cinq groupes : avant l’inscription (179 et 33), confirmation (173), acheminement (217), maîtrise de la relation (174, 175 et 176), puis consultation (177 et 178). Un rappel précise que d’autres règles transversales peuvent s’appliquer.

### Avant

- 179
- 33

### Confirmer et acheminer

- Confirmer : 173
- Acheminer : 217

### Garder la maîtrise

- 174
- 175
- 176

### Consulter

- 177
- 178

### Périmètre

D’autres règles transversales peuvent aussi s’appliquer.

### Message à retenir

Ces neuf règles cadrent le parcours étudié sans épuiser les exigences transversales.

### Discours oral

Ce parcours est sécurisé par l’application stricte des règles 173 à 179. Elles constituent le socle minimal d’exigences, et non une option d’excellence.

**Un fil de lecture, pas une sélection exhaustive**

Cette sélection sert de fil de lecture. Elle ne recense pas toutes les règles susceptibles de concerner les formulaires, les données personnelles, la sécurité ou le site. Les règles #33 (e-commerce) et #217 (sécurité) en sont deux exemples.

**Relier chaque règle à son impact**

Pour réussir les questions portant sur la thématique Newsletter, il faut dépasser la simple mémorisation des libellés. Demandez-vous systématiquement quel préjudice subit l’utilisateur si une règle n’est pas appliquée.

- Un processus d’inscription irréprochable perd toute sa valeur si le lien de désabonnement est absent de l’e-mail envoyé.
- Un formulaire clair ne sert à rien si les e-mails envoyés finissent systématiquement dans les spams parce que le domaine d’envoi n’est pas authentifié (règle 217).

**Deux pièges à repérer**

- La dissymétrie entre inscription et désinscription : l’inscription exige un processus de confirmation (règle 173), tandis que la désinscription ne doit pas demander de confirmation par courriel (règle 175).
- Le double canal de désinscription : un lien figure dans chaque newsletter (règle 174), et la désinscription doit aussi être possible depuis le site (règle 176).

**Maîtriser le vocabulaire exact du glossaire**

- **Opt-in** : consentement explicite de l’utilisateur.
- **Opt-out** : consentement implicite ; l’utilisateur doit s’opposer, par exemple en décochant une option précochée. La règle 33 interdit l’activation par défaut de l’inscription à un service annexe (thématique E-commerce).
- **Processus de confirmation** : étape qui confirme l’inscription à la newsletter (règle 173).
- **Version en ligne** : solution de repli pour consulter la dernière newsletter dans un navigateur (règle 177).

## Slide 3 - Savoir avant de s’abonner

### Lecture du visuel

La règle 179 est associée à une page d’abonnement. La fréquence annoncée apparaît avant un champ d’adresse encore vide, pour permettre un choix éclairé avant toute saisie.

### Règle 179

La fréquence d’envoi des newsletters est consultable avant l’abonnement.

### Lecture de l’interface

- La fréquence est annoncée avant la saisie.
- Le champ d’adresse est encore vide.
- L’utilisateur peut choisir en connaissance de cause.

### Vérification

À vérifier : la fréquence avant toute saisie.

### Message à retenir

La fréquence doit pouvoir être consultée avant que l’abonné saisisse son adresse.

### Discours oral

Avant de donner son adresse, l’utilisateur doit savoir à quel rythme il recevra les messages. L’information apparaît donc avant le champ.

La règle 179 n’impose pas une fréquence mensuelle ni un rythme particulier. Une fréquence irrégulière peut être annoncée comme telle : l’information doit être disponible avant l’abonnement.

**Relier la règle à son impact : préjudices et risques**

Si la fréquence n’est pas indiquée avant l’abonnement, l’utilisateur peut s’engager sans savoir à quel rythme il recevra les messages.

Il risque alors une sur-sollicitation, une déception, voire un sentiment d’intrusion. Cela peut entraîner un désabonnement rapide ou une perte de confiance.

**Ce que garantit la règle**

La règle 179 garantit que l’utilisateur connaît la fréquence d’envoi avant de s’abonner et peut donc décider en connaissance de cause. Si la fréquence n’est pas régulière, une indication adaptée reste possible, par exemple « au fil de l’actualité ».

> **Mémo -** Je sais à quelle fréquence je vais recevoir la newsletter avant de m’abonner.

## Slide 4 - Laissez l’utilisateur choisir

### Lecture du visuel

Deux états d’une commande sont comparés. À gauche, l’option de newsletter est cochée par défaut ; à droite, elle est vide et l’utilisateur peut l’activer volontairement.

### Règle 33

L’inscription à des services annexes n’est pas activée par défaut.

### Deux états comparés

- Case newsletter cochée au chargement.
- Case newsletter vide, à activer par une action volontaire.

### Vérification

À vérifier : aucune inscription précochée au chargement.

### Message à retenir

Lorsqu’elle est proposée pendant une commande, l’inscription ne doit pas être activée par défaut.

### Discours oral

La règle 33 concerne ici l’inscription à un service annexe proposée dans un parcours de commande. Le premier état montre une option déjà cochée ; le second laisse la décision à l’utilisateur.

Une case qu’il est possible de décocher reste une option activée par défaut : c’est de l’opt-out. Cette règle ne se généralise pas à tous les formulaires.

**Relier la règle à son impact : préjudices et risques**

Si un service annexe est activé par défaut, l’utilisateur peut souscrire sans l’avoir réellement choisi.

Il peut subir un surcoût, recevoir des sollicitations non désirées ou devoir effectuer des démarches pour annuler. Cela crée de la frustration et peut provoquer une perte de confiance.

**Ce que garantit la règle**

La règle 33 garantit que l’utilisateur reste maître de ses choix : un service annexe doit résulter d’une action volontaire et explicite. C’est le principe de l’**opt-in**, par opposition à l’**opt-out**.

> **À retenir à l’oral -** « Si je n’ai rien choisi, rien ne doit être ajouté ou activé pour moi. »

## Slide 5 - Confirmer avant d’activer

### Lecture du visuel

Une demande d’inscription passe par un courriel et une action de confirmation. L’état « Abonnement actif » n’arrive qu’après cette action ; avant, le statut est « En attente ».

### Règle 173

L’inscription aux newsletters est soumise à un processus de confirmation.

### Étapes représentées

1. Demande d’inscription
2. Courriel de confirmation
3. Abonnement en attente
4. Action de confirmation
5. Abonnement actif

### Vérification

À tester : l’abonnement reste inactif avant confirmation.

### Message à retenir

La demande ne devient pas un abonnement actif avant la fin du processus de confirmation.

### Discours oral

La saisie de l’adresse lance une demande, mais ne suffit pas à activer l’abonnement. Une action doit encore avoir lieu depuis le message reçu ; le double opt-in est un nom courant pour ce mécanisme.

Pour le vérifier, suivons un parcours de test et observons l’état avant puis après la confirmation. Un accusé de réception du formulaire ne prouve pas à lui seul que l’adresse est abonnée.

**Relier la règle à son impact : préjudices et risques**

Sans processus de confirmation, un tiers peut inscrire quelqu’un à son insu, ou une simple erreur de saisie peut enregistrer une mauvaise adresse.

L’utilisateur risque alors de recevoir des messages non sollicités, ou au contraire de ne jamais recevoir la newsletter attendue.

Cela crée de l’agacement et peut dégrader la confiance dans l’utilisation de ses données.

**Ce que garantit la règle**

La règle 173 garantit que l’abonnement est confirmé par le véritable détenteur de l’adresse e-mail. Elle permet aussi de vérifier que l’adresse saisie est correcte et de renforcer la confiance de l’utilisateur dans la gestion de ses données.

> **À retenir à l’oral -** « Je confirme depuis ma boîte mail que c’est bien moi qui veux m’abonner. »

## Slide 6 - Authentifiez le domaine d’envoi

### Lecture du visuel

Le courriel traverse trois contrôles nommés SPF, DKIM et DMARC avant la réception. La slide associe ces mécanismes à la réduction des risques d’usurpation et de classement en spam.

### Règle 217

Le domaine de messagerie est authentifié.

### Trois mécanismes

- SPF : serveurs autorisés.
- DKIM : signature.
- DMARC : politique et rapports.

### Contrôles

- Examiner les enregistrements DNS.
- Vérifier les en-têtes d’un courriel reçu.

### Portée

L’authentification réduit les risques d’usurpation et de spam ; elle ne garantit pas la réception en boîte principale.

### Message à retenir

L’authentification réduit les risques d’usurpation, sans garantir l’arrivée en boîte principale.

### Discours oral

La règle 217 porte sur l’authentification du domaine de messagerie.

Le dessin ne signifie pas qu’un message authentifié arrivera nécessairement dans la boîte principale. Un contrôle réel passe par les enregistrements DNS et les en-têtes d’un courriel reçu, en vérifiant leur cohérence avec le domaine affiché.

**Relier la règle à son impact : préjudices et risques**

Si le domaine de messagerie n’est pas authentifié, l’utilisateur peut recevoir de **faux e-mails semblant provenir du service**, avec des risques de phishing, d’usurpation ou de fraude.

À l’inverse, les messages légitimes du service peuvent être **classés en spam ou bloqués**, ce qui peut empêcher la réception d’une confirmation, d’une alerte ou d’un lien important.

Cela nuit directement à la confiance dans le service.

**Ce que garantit la règle**

La règle 217 garantit que les e-mails envoyés au nom du domaine sont **mieux identifiés comme légitimes** par les services de messagerie. Elle contribue à **limiter l’usurpation**, à améliorer la délivrabilité des messages et à renforcer la confiance de l’utilisateur.

> **À retenir à l’oral -** « Le message vient-il vraiment du bon domaine, et arrivera-t-il bien jusqu’à l’utilisateur ? »

**Repère technique à conserver dans les notes**

L’authentification repose sur trois mécanismes complémentaires :

- **SPF** autorise les serveurs d’envoi.
- **DKIM** signe les messages.
- **DMARC** définit la politique à appliquer lorsque les contrôles échouent et permet de recevoir des rapports.

## Slide 7 - Chaque envoi contient sa porte de sortie

### Lecture du visuel

Plusieurs éditions de newsletter sont représentées, chacune avec un lien « Se désinscrire ». La slide distingue le lien présent et repérable du résultat réel, à vérifier en suivant le parcours.

### Règle 174

Un lien de désinscription est présent dans chaque newsletter.

### Lecture du visuel

- Le lien figure dans chaque édition représentée.
- Le lien doit être repérable et activable.

### Test

À tester : le lien mène à une désinscription effective.

### Message à retenir

Le lien doit figurer dans chaque newsletter et mener à une sortie effective.

### Discours oral

La règle 174 demande un lien dans chaque envoi. Sa présence visuelle n’est qu’un premier contrôle : il faut activer le lien et vérifier que le parcours aboutit à une désinscription réelle.

Pour un audit, ne tester qu’un gabarit récent ne prouve pas le fonctionnement des anciennes éditions. Vérifions plusieurs messages et la conséquence sur les envois pour l’abonnement de test.

**Relier la règle à son impact : préjudices et risques**

Sans lien de désinscription dans la newsletter, l’utilisateur peut continuer à recevoir des messages qu’il ne souhaite plus sans moyen simple d’y mettre fin.

Il doit alors chercher une autre solution, contacter le service ou signaler les messages comme indésirables.

Cela crée de la frustration et peut fortement dégrader la confiance dans l’usage de ses données.

**Ce que garantit la règle**

La règle 174 garantit que l’abonné peut cesser facilement de recevoir la newsletter depuis chaque message reçu. Elle lui permet de garder la maîtrise de son abonnement et renforce la confiance dans le respect de ses choix.

> **À retenir à l’oral -** « Je peux me désabonner directement depuis n’importe quelle newsletter reçue. »

## Slide 8 - Se désinscrire sans nouveau courriel

### Lecture du visuel

Deux suites sont opposées après une demande de désinscription : une confirmation en ligne qui mène à la sortie, et une boucle vers un nouveau courriel puis une attente, signalée comme le parcours à éviter.

### Règle 175

La désinscription depuis une newsletter ne demande pas de confirmation par courriel.

### Parcours possibles

- Confirmation en ligne, puis désinscription.
- Nouveau courriel et attente : détour à éviter.

### Nuance

Un écran de confirmation en ligne est possible ; un nouveau courriel obligatoire ne l’est pas.

### Message à retenir

Une confirmation peut se faire en ligne ; la désinscription ne doit pas exiger un nouveau courriel.

### Discours oral

La règle 175 écarte la confirmation par courriel. Elle n’interdit pas un écran en ligne qui demande de confirmer le choix, par exemple pour éviter une désinscription involontaire.

Ne présentons donc pas le premier clic comme forcément suffisant : suivons le parcours jusqu’au résultat et vérifions qu’il ne demande pas un nouveau message pour terminer.

**Relier la règle à son impact : préjudices et risques**

Si la désinscription exige encore une confirmation par e-mail, l’utilisateur doit effectuer une étape supplémentaire inutile alors qu’il a déjà exprimé son choix.

Cela crée de la friction, de l’agacement et peut donner l’impression que le service cherche à compliquer la sortie. Cette étape génère aussi un échange de courriel évitable.

**Ce que garantit la règle**

La règle 175 garantit une désinscription simple et directe, sans nouvel e-mail à valider. Une confirmation en ligne peut toutefois être proposée pour éviter une désinscription accidentelle.

Cela respecte le choix de l’utilisateur, réduit les échanges inutiles et renforce la confiance.

> **À retenir à l’oral -** « Je me désabonne en ligne, sans avoir à confirmer encore une fois par e-mail. »

## Slide 9 - Trouver la sortie depuis le site

### Lecture du visuel

Depuis la navigation du site, l’utilisateur ouvre la gestion de ses abonnements puis se désinscrit. Un écran final confirme « Désinscription effectuée » et indique que les newsletters ne seront plus reçues.

### Règle 176

La désinscription aux newsletters est possible depuis le site.

### Parcours représenté

1. Ouvrir la rubrique Newsletter depuis la navigation.
2. Accéder à la gestion des abonnements.
3. Se désinscrire.
4. Lire la confirmation : « Désinscription effectuée ».

### Vérification

À tester : la page est trouvable et les envois s’arrêtent effectivement.

### Message à retenir

La désinscription doit aussi être trouvable depuis le site et produire un résultat effectif.

### Discours oral

La règle 176 prévoit une possibilité de désinscription depuis le site, sans dépendre de la recherche d’un ancien courriel. Le parcours illustré passe par la navigation, la gestion de l’abonnement et une confirmation du résultat.

En audit, partons de la navigation ordinaire, utilisons le dispositif et vérifions que les envois cessent. La page doit être trouvable et la confirmation compréhensible.

**Relier la règle à son impact : préjudices et risques**

Si la désinscription n’est possible que depuis une newsletter reçue, l’utilisateur peut se retrouver bloqué s’il ne retrouve plus le message concerné.

Il doit alors fouiller dans sa messagerie, contacter le support ou recourir au signalement en spam.

Cela crée de la frustration et peut donner le sentiment que le service complique volontairement la désinscription.

**Ce que garantit la règle**

La règle 176 garantit que l’utilisateur peut se désabonner directement depuis le site, sans dépendre d’un ancien e-mail. Il conserve ainsi une voie de sortie permanente et autonome, ce qui renforce la confiance dans l’utilisation de ses données.

> **À retenir à l’oral -** « Même sans retrouver une ancienne newsletter, je peux me désabonner depuis le site. »

## Slide 10 - Une sortie trouvable, sans détour inutile

### Lecture du visuel

Deux entrées, « Newsletter » et « Site », convergent vers un désabonnement effectif. Une confirmation en ligne apparaît sur le parcours depuis la newsletter ; le schéma ne pose pas d’exigence de symétrie entre entrée et sortie.

### Deux voies vers la sortie

- Depuis une newsletter.
- Depuis le site.

### Résultat commun

Désabonnement effectif.

### Confirmation

Une confirmation en ligne est représentée sur le parcours depuis la newsletter.

### Message à retenir

Depuis le courriel ou le site, l’abonné doit pouvoir trouver une sortie qui aboutit.

### Discours oral

Ici, on fait la synthèse des trois règles consacrées à la désinscription.

**Trois règles pour organiser la désinscription**

**Deux voies pour sortir**

L’idée principale, c’est que l’abonné dispose de deux voies pour sortir :

1. **Depuis la newsletter - règle 174** : chaque newsletter doit contenir un lien de désinscription.
2. **Depuis le site - règle 176** : même si l’utilisateur n’a plus la newsletter sous la main, il doit pouvoir retrouver une possibilité de se désabonner en ligne.

**Pas de courriel supplémentaire - règle 175**

Lorsqu’on se désabonne depuis une newsletter, on ne doit pas avoir à recevoir un nouveau courriel pour confirmer cette désinscription. Une confirmation directement sur la page web peut en revanche être proposée.

**Une logique différente entre l’inscription et la sortie**

À l’inscription, la règle 173 demande un processus de confirmation, notamment pour éviter qu’une adresse soit inscrite par erreur ou à l’insu de son propriétaire. À la sortie, la logique est différente : l’utilisateur a exprimé sa volonté de partir, on cherche donc à simplifier son parcours.

**À retenir**

> **Pour s’inscrire, on confirme. Pour se désinscrire, on simplifie.**

Une sortie depuis le courriel, une autre depuis le site, sans détour inutile.

## Slide 11 - La dernière édition est aussi en ligne

### Lecture du visuel

La newsletter reçue et la page d’abonnement conduisent toutes deux vers une page Web affichant la dernière édition et un accès « Lire en ligne ». Une consigne demande de vérifier que le contenu s’ouvre et se consulte réellement.

### Règle 177

La dernière newsletter envoyée est disponible en ligne.

### Accès à la dernière édition

- Depuis le courriel.
- Depuis la page d’abonnement.
- Lire en ligne.

### Vérification

À vérifier : l’édition s’ouvre et son contenu se consulte réellement.

### Message à retenir

La dernière newsletter envoyée doit pouvoir être réellement consultée en ligne.

### Discours oral

La règle 177 permet de consulter la dernière newsletter hors de la messagerie. Elle peut aussi aider une personne à voir ce qu’elle recevra avant de s’abonner.

Pour vérifier, suivons les accès depuis le courriel et la page d’abonnement, puis ouvrons l’édition. Une vignette ou un lien qui ne mène pas au contenu ne suffit pas.

**Préjudices et risques pour l’utilisateur**

Si la dernière newsletter envoyée n’est pas disponible en ligne, plusieurs difficultés peuvent apparaître.

1. **Difficulté de consultation** : une newsletter peut être mal affichée dans certains logiciels de messagerie ou sur certains équipements. Sans version en ligne, l’utilisateur ne dispose pas de solution alternative pour accéder correctement au contenu.
2. **Absence d’aperçu** : un futur abonné doit s’inscrire sans pouvoir consulter un exemple récent de la newsletter ni voir concrètement ce qu’il va recevoir.
3. **Visibilité limitée au courriel** : le contenu bénéficie moins de la visibilité et de l’indexation d’une publication accessible directement sur le web.

**Ce que garantit le respect de la règle à l’utilisateur**

La mise en ligne de la dernière newsletter apporte une solution de consultation indépendante du logiciel de messagerie. L’utilisateur peut retrouver le contenu directement dans son navigateur.

Elle permet aussi au futur abonné de se faire une idée de la newsletter avant de s’inscrire : son contenu, son format et le type d’informations proposées deviennent immédiatement visibles.

Enfin, la mise en ligne permet au contenu d’être mieux pris en compte par les moteurs de recherche et contribue au référencement du site.

**Ce que garantit le dispositif**

La dernière newsletter ne reste donc pas uniquement dans les boîtes mail. Elle devient un contenu web à part entière, consultable en dehors de la messagerie, visible avant l’abonnement et accessible aux moteurs de recherche.

Concrètement, cette dernière édition peut être proposée en HTML ou éventuellement en PDF, et être accessible depuis le site, notamment à proximité du formulaire d’abonnement.

**À retenir à l’oral**

> « La dernière newsletter doit aussi exister sur le web : comme solution de repli pour la consultation, comme aperçu avant l’abonnement et comme contenu visible pour les moteurs de recherche. »

## Slide 12 - Garder les anciennes éditions consultables

### Lecture du visuel

Un rayon d’éditions envoyées, organisé par dates, est opposé à quelques exemples isolés. La slide rappelle que les archives sont disponibles en ligne et qu’il faut vérifier l’accès aux éditions envoyées.

### Règle 178

Les archives de newsletters sont disponibles en ligne.

### Éléments à retrouver

- Les éditions envoyées.
- Des repères de date.
- Un accès aux contenus archivés.

### Vérification

À vérifier : les éditions envoyées restent accessibles.

Quelques exemples isolés ne constituent pas les archives du service.

### Message à retenir

Les archives doivent être accessibles en ligne ; quelques exemples ne remplacent pas les éditions envoyées.

### Discours oral

Après la dernière édition, nous regardons la mémoire du service. La règle 178 porte sur la disponibilité des archives en ligne ; le visuel distingue ces archives d’une sélection de quelques exemples.

Pour contrôler le dispositif, ouvrons la page d’archives et vérifions les éditions envoyées ainsi que leur accès. Nous ne pouvons pas conclure à partir d’une page vide ou d’une seule édition mise en avant.

**Risques pour l’utilisateur**

Sans archives, l’utilisateur peut perdre définitivement une information reçue par mail.

Un futur abonné ne peut pas non plus consulter les anciens numéros pour juger la qualité ou les sujets traités.

**Ce que garantit la règle**

Les anciennes newsletters restent accessibles et consultables dans le temps.

Cela améliore la traçabilité de l’information, permet de retrouver un ancien contenu et aide un futur abonné à se faire une idée de la newsletter.

**À retenir**

> Une newsletter ne doit pas disparaître après son envoi : ses archives doivent rester disponibles en ligne.

## Slide 13 - La newsletter ne vit pas seule

### Lecture du visuel

La page de newsletter est placée au sein d’un site. Quatre domaines voisins sont reliés au parcours : formulaire, données personnelles, sécurité et contact. Le callout invite à auditer l’environnement du service.

### Domaines reliés à la newsletter

- Formulaire
- Données personnelles
- Sécurité
- Contact

### Périmètre

Auditer aussi le parcours qui entoure la newsletter.

Ces domaines transversaux ne constituent pas une liste exhaustive de règles.

### Message à retenir

Les règles dédiées à la newsletter ne remplacent pas la relecture des autres éléments du parcours.

### Discours oral

Les neuf règles donnent un cadre utile, mais l’abonné traverse aussi un formulaire et un site, et fournit des données personnelles. Le contact avec l’organisme et la sécurité des pages entrent aussi dans l’expérience.

Ces thèmes sont des dimensions à examiner, pas une nouvelle liste exhaustive de règles. L’audit peut s’élargir à partir des interfaces et des données réellement présentes.

**Interdépendances et règles transversales (QSE-IP)**

La maîtrise de la newsletter est indissociable du cadre QSE-IP : Qualité, Sécurité, Environnement, Inclusion et Privacy.

**Privacy et données personnelles**

Les fichiers d’abonnés contiennent des données identifiantes. Tout traitement doit reposer sur une base légale appropriée. Lorsque le consentement est retenu, il doit être libre, spécifique, éclairé et univoque, et la personne doit pouvoir le retirer. Le droit à l’effacement s’exerce dans les conditions prévues par le RGPD ; les fichiers doivent être sécurisés.

- Après un clic sur le lien de désinscription, une éventuelle confirmation se fait en ligne, sans demander de confirmation supplémentaire par courriel (règle 175).

**Inclusion et accessibilité**

- Les gabarits d’e-mails doivent être compatibles avec les lecteurs d’écran.
- La structure des messages - titres et alternatives textuelles des images - permet aux personnes en situation de handicap d’accéder au contenu.

**Environnement et écoconception**

- Pour réduire l’impact environnemental, optimisez le poids des images et éliminez les données inutiles. Sur les pages du service, supprimez aussi les scripts superflus.
- La sobriété éditoriale limite la pollution numérique liée au stockage.

**Sécurité et formulaires**

- La phase d’abonnement est un point critique de sécurité.
- Une gestion rigoureuse des erreurs de saisie prévient la frustration et les abandons tout en protégeant l’intégrité de la base de données.

**E-commerce**

- Sur les sites transactionnels, la newsletter ne doit jamais devenir un vecteur de vente forcée ni entraîner l’ajout automatique de services annexes au panier (règle 33).

## Slide 14 - Relire le parcours avec VPTCS

### Lecture du visuel

Le parcours newsletter est relié à cinq questions : où trouver le service, que comprendre, si le mécanisme est fiable, quel contenu consulter et quel service gérer.

### Les cinq attentes

- Visibilité : où trouver le service ?
- Perception : que comprendre ?
- Technique : est-ce fiable ?
- Contenus : que consulter ?
- Services : que gérer ?

### Question de relecture

VPTCS relit l’expérience dans son ensemble.

### Message à retenir

VPTCS permet de relire l’expérience de la newsletter dans son ensemble.

### Discours oral

La newsletter sous le prisme du modèle VPTCS

Il permet de décomposer l’expérience utilisateur en cinq exigences fondamentales, garantissant que la newsletter remplit sa mission sans générer de friction ou de dette technique.

1. **Visibilité** - accès au service : au-delà du trafic direct, la newsletter sécurise l’indépendance de l’organisation face aux algorithmes tiers et nourrit la crédibilité nécessaire au GEO (Generative Engine Optimization).
2. **Perception** - compréhension : l’interface d’abonnement et les messages doivent garantir une lisibilité parfaite et une accessibilité universelle (inclusion), permettant à tout utilisateur, quelle que soit sa situation, de percevoir l’information.
3. **Technique** - fonctionnement et fiabilité : ce pilier exige l’interopérabilité entre clients de messagerie et une vigilance stricte contre la surenchère de données. Le fonctionnement des liens et des formats d’envoi doit être irréprochable.
4. **Contenus** - consultation et recherche : la valeur ajoutée repose sur la pertinence de l’information. Un contenu mal structuré ou non daté dégrade immédiatement l’autorité de l’émetteur.
5. **Services** - gestion de l’abonnement et possibilité d’en sortir : la qualité d’une newsletter se juge principalement après le clic. Elle doit accompagner l’usager via des confirmations explicites et une gestion granulaire des préférences.

**Une responsabilité distribuée**

La qualité des newsletters ne relève pas du seul service marketing. Elle se construit entre plusieurs métiers :

- **Rédaction** : veiller à la pertinence des contenus.
- **Développement** : assurer l’interopérabilité des messages.
- **Conformité** : protéger les données personnelles et respecter le RGPD.

**Installer une démarche et une culture de qualité partagée**

L’enjeu est de passer d’une conformité subie à une démarche proactive. En anticipant les exigences, l’organisation peut transformer les contraintes en leviers de différenciation.

## Slide 15 - Cas pratique : auditez ce dossier

### Lecture du visuel

Un dossier réunit trois surfaces. Le formulaire a une case newsletter cochée et affiche « Abonnement activé » après validation ; le courriel reçu annonce un message supplémentaire pour confirmer la désinscription ; le site affiche une dernière édition et des archives sans contenu. La question invite à compter les problèmes sans donner les numéros de règle.

### Formulaire

- Adresse e-mail.
- Option « Recevoir la newsletter » cochée.
- Bouton « Valider ».
- État affiché : « Abonnement activé ».

### Courriel reçu

- Lien « Se désinscrire ».
- Message annonçant qu’un courriel de confirmation sera envoyé.

### Site

- Dernière édition : aucun contenu.
- Archives : aucun contenu.

### Consigne

Combien de problèmes repérez-vous ?

Le dossier n’affiche pas les numéros de règle.

### Message à retenir

Repérer les anomalies sur plusieurs surfaces avant de les relier aux règles et aux preuves nécessaires.

### Discours oral

Laissez quelques instants au groupe pour examiner le dossier sans afficher de numéros de règle. On peut guider le regard du formulaire vers le courriel reçu, puis vers la page du site.

**Exemple public : la newsletter Opquast**

Pour illustrer ces exigences, regardons la page publique de la newsletter Opquast :

- **Fréquence** : les envois sont annoncés comme mensuels.
- **Ligne éditoriale** : la page présente un éditorial, des actualités, des liens et des offres d’emploi.
- **Confirmation** : le formulaire précise que l’inscription doit être confirmée par e-mail, selon le principe du double opt-in.
- **Désabonnement** : un lien est prévu dans chaque newsletter. Le site propose aussi une page de désabonnement aux personnes qui possèdent un compte Opquast.
- **Données et prestataire** : la page explique que l’adresse e-mail sert à envoyer la newsletter et cite Mailjet comme prestataire de gestion des envois.
- **Archives** : les éditions précédentes restent accessibles sur le site.

**Source** : https://www.opquast.com/ressources/newsletter/

## Slide 16 - Observer ne suffit pas toujours

### Lecture du visuel

La correction répartit les contrôles en trois postes. L’écran et les éditions couvrent les règles 33, 179, 177 et 178 ; le parcours réel couvre les règles 173, 174, 175 et 176 ; le contrôle technique de la règle 217 exige DNS et en-têtes, pas une simple capture.

### Écran et éditions : 33, 179, 177, 178

Observer la page, puis ouvrir les éditions pour vérifier les informations.

- Édition Web
- Édition texte
- Édition HTML

### Parcours réel : 173, 174, 175, 176

Suivre le parcours complet de l’inscription à la désinscription.

- Inscription
- Réception du message
- Désinscription
- Désinscription effective

### Technique : 217

Vérifier l’authentification par un contrôle technique, pas par une simple capture.

- DNS
- DMARC
- En-têtes

### Question

La page suffit-elle pour vérifier l’authentification ? Non : DNS et en-têtes sont nécessaires.

### Message à retenir

Choisir la preuve adaptée : observation des contenus, test du parcours ou contrôle technique.

### Discours oral

Idée à faire passer : toutes les règles ne se vérifient pas avec le même type de preuve.

**Écran et éditions**

Certaines règles se contrôlent directement sur la page ou en ouvrant les éditions de la newsletter : fréquence annoncée, dernière édition, archives disponibles.

**Parcours réel**

D’autres nécessitent de réaliser le parcours complet : inscription, réception du message, présence et fonctionnement de la désinscription.

**Contrôle technique**

Pour la règle 217, une capture ne suffit pas. Il faut vérifier les DNS et les en-têtes du message pour contrôler l’authentification du domaine.

**Conclusion**

À chaque règle sa preuve : observer, tester ou inspecter techniquement.

## Slide 17 - Retenir les neuf règles en trois temps

### Lecture du visuel

Trois bandes temporelles organisent les règles. Avant d’entrer : 179 et 33, informer et choisir. Pendant la relation : 173, 217, 174, 175 et 176, confirmer, acheminer et se désinscrire. Après l’envoi : 177 et 178, consulter et retrouver.

### Avant d’entrer

- 179 : informer sur la fréquence.
- 33 : laisser choisir.

### Pendant la relation

- 173 : confirmer.
- 217 : acheminer.
- 174 : se désinscrire depuis chaque newsletter.
- 175 : sans nouveau courriel.
- 176 : depuis le site.

### Après l’envoi

- 177 : consulter.
- 178 : retrouver.

### Message

Les numéros repèrent les règles ; le parcours aide à les retenir.

### Message à retenir

Les numéros repèrent les règles ; le parcours aide à les retenir.

### Discours oral

Reprenons les neuf numéros dans l’ordre du parcours. Avant d’entrer, l’abonné s’informe sur la fréquence et choisit de s’inscrire. Pendant la relation, il confirme l’adresse, reçoit les messages et garde la maîtrise de sa désinscription.

Après l’envoi, il peut consulter la dernière édition et retrouver les précédentes. Les groupes servent de repère ; ils ne remplacent pas le libellé complet des règles.

**Trois bénéfices stratégiques**

1. **Sécurité juridique et industrielle** : réduire les risques de sanctions liées au RGPD et protéger la réputation technique de l’infrastructure d’envoi.
2. **Délivrabilité** : la réduction des signalements de spam et l’allègement des messages favorisent l’arrivée des contenus dans la boîte de réception.
3. **Capital confiance et E-E-A-T** : une relation transparente et respectueuse peut renforcer la fidélité des usagers et la crédibilité de l’organisation face aux moteurs de réponse fondés sur l’IA.

**Construire des services plus solides, plus responsables et plus performants**

Une application stricte du référentiel vise des bénéfices concrets :

- **Déclencheur** : anticiper les risques et les besoins.
- **Objectif** : améliorer la qualité pour l’utilisateur.
- **Vécu** : proposer une expérience positive.
- **Relation** : renforcer la crédibilité et la confiance.
- **Pilotage** : mieux maîtriser les coûts cachés.

## Slide 18 - Testez le parcours de bout en bout

### Lecture du visuel

Une adresse témoin passe par la confirmation, la réception puis la désinscription, avec l’état actif après confirmation et l’arrêt des envois après la sortie. Deux contrôles complémentaires portent sur les éditions en ligne et le domaine d’envoi, avec DNS.

### Cycle de l’adresse témoin

1. Confirmer la demande.
2. Recevoir la newsletter.
3. Se désinscrire.
4. Vérifier l’arrêt des envois.

### États à constater

- Abonnement actif après confirmation.
- Arrêt des envois après désinscription.

### Preuves complémentaires

- Consulter les éditions en ligne.
- Vérifier le domaine à partir des données DNS et des en-têtes.

### Message

Une adresse témoin. Un cycle complet. Des preuves.

### Message à retenir

Un cycle de test produit des preuves utiles, complétées par des contrôles des éditions et du domaine.

### Discours oral

Pour conclure, réalisons un cycle avec une adresse témoin : demander l’inscription, confirmer l’adresse, vérifier la réception, puis se désinscrire et observer l’arrêt des envois.

Ce cycle ne prouve pas à lui seul que le lien fonctionne dans chaque ancienne édition ni que les archives sont complètes. Il faut aussi ouvrir les éditions en ligne et contrôler le domaine à partir des données DNS et des en-têtes nécessaires.
